// Inventory.cpp - Implements inventory logic such as add, delete, and search

// Inventory.cpp : Handles inventory loading, saving, searching, and product sales in a POS system for Target

#include "Inventory.h"
#include "Product.h"
#include "Tobacco.h"
#include "LotteryTickets.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <iomanip>
#include <stdexcept>
#include <ctime> // for age check

using namespace std;

// Load products from a file into inventory
void InventoryManager::loadInventoryFromFile(const string& filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        throw runtime_error("Could not open the file!");
    }

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        vector<string> tokens;
        string token;

        while (getline(ss, token, '|')) {
            tokens.push_back(token);
        }

        string category = tokens[0];
        string id = tokens[1];
        string name = tokens[2];
        string expDate = tokens[3];
        double price = stod(tokens[4]);

        // Check category and create appropriate product type
        if (category == "Tobacco") {
            double tax = stod(tokens[5]);
            inventory.push_back(make_shared<Tobacco>(id, category, name, expDate, price, tax));
        }
        else if (category == "Lottery") {
            double cityTax = stod(tokens[5]);
            double countyTax = stod(tokens[6]);
            inventory.push_back(make_shared<LotteryTickets>(id, category, name, expDate, price, cityTax, countyTax));
        }
        else {
            inventory.push_back(make_shared<Product>(id, category, name, expDate, price));
        }
    }

    file.close();
    cout << "Inventory loaded from " << filename << endl;
}

// Save all inventory items to a file
void InventoryManager::saveInventoryToFile(const string& filename) const {
    ofstream file(filename);
    if (!file.is_open()) {
        throw runtime_error("Could not open file for saving!");
    }

    for (const auto& product : inventory) {
        file << product->getDepartment() << "|"
            << product->getId() << "|"
            << product->getName() << "|"
            << product->getExpDate() << "|"
            << fixed << setprecision(2) << product->registerPrice();

        if (auto tobacco = dynamic_pointer_cast<Tobacco>(product)) {
            file << "|" << tobacco->getTobaccoTax();
        }
        else if (auto lottery = dynamic_pointer_cast<LotteryTickets>(product)) {
            file << "|" << lottery->getCityTax() << "|" << lottery->getCountyTax();
        }

        file << endl;
    }

    file.close();
    cout << "Inventory saved to " << filename << endl;
}

// Add a new product to inventory
void InventoryManager::addProduct(shared_ptr<Product> product) {
    inventory.push_back(product);
    cout << "Product added successfully.\n";
}

// Remove a product from inventory by ID
void InventoryManager::removeProduct() {
    string productId;
    cout << "Enter product ID to remove: ";
    cin >> productId;

    auto it = find_if(inventory.begin(), inventory.end(),
        [&productId](const shared_ptr<Product>& p) {
            return p->getId() == productId;
        });

    if (it != inventory.end()) {
        cout << "Product removed: " << (*it)->getName() << endl;
        inventory.erase(it);
    }
    else {
        throw runtime_error("Product not found.");
    }
}

// Search for a product by name or ID
void InventoryManager::searchInventory(const string& searchTerm) const {
    bool found = false;
    for (const auto& p : inventory) {
        if (p->getId() == searchTerm || p->getName() == searchTerm) {
            p->display();
            cout << endl;
            found = true;
        }
    }
    if (!found) {
        throw runtime_error("This product was not found.");
    }
}

// List products by category
void InventoryManager::searchByCategory(const string& category) const {
    bool found = false;
    for (const auto& p : inventory) {
        if (p->getDepartment() == category) {
            p->display();
            cout << endl;
            found = true;
        }
    }
    if (!found) {
        throw runtime_error("No products found in this category.");
    }
}

// List products in a specific price range
void InventoryManager::searchByPriceRange(double min, double max) const {
    bool found = false;
    for (const auto& p : inventory) {
        double price = p->registerPrice();
        if (price >= min && price <= max) {
            p->display();
            cout << endl;
            found = true;
        }
    }
    if (!found) {
        throw runtime_error("No products found in this price range.");
    }
}

// Process selling a product
void InventoryManager::sellProduct() {
    string productId;
    cout << "\nEnter product ID to sell: ";
    cin >> productId;

    auto it = find_if(inventory.begin(), inventory.end(),
        [&productId](const shared_ptr<Product>& p) {
            return p->getId() == productId;
        });

    if (it == inventory.end()) {
        throw runtime_error("Product not found in inventory.");
    }

    (*it)->display();

    // Check age if it's a tobacco product
    if ((*it)->getDepartment() == "Tobacco") {
        cout << "\nMust be 21+ to purchase tobacco.\nEnter DOB (YYYY-MM-DD): ";
        string dob;
        cin >> dob;

        int year;
        stringstream(dob.substr(0, 4)) >> year;

        time_t now = time(0);
        tm localTime;
        localtime_s(&localTime, &now);
        int currentYear = 1900 + localTime.tm_year;
        if (currentYear - year < 21) {
            cout << "You must be 21 or older.\nTransaction cancelled.\n";
            return;
        }
    }

    // Target Circle
    char member;
    cout << "Target Circle member? (Y/N): ";
    cin >> member;
    if (toupper(member) == 'Y') {
        string phone;
        cout << "Enter phone number: ";
        cin >> phone;
    }

    // RedCard Discount
    char hasCard;
    bool usedCard = false;
    cout << "Do you have a Target RedCard? (Y/N): ";
    cin >> hasCard;

    double total = (*it)->registerPrice();
    if (toupper(hasCard) == 'Y') {
        total *= 0.95;
        usedCard = true;
    }

    cout << fixed << setprecision(2);
    cout << "Total: $" << total << endl;

    // Payment
    cout << "Choose payment: 1) Debit 2) Credit 3) Cash: ";
    int payMethod;
    cin >> payMethod;

    string type;
    bool success = false;

    if (payMethod == 1 || payMethod == 2) {
        double bal;
        cout << "Card balance: $";
        cin >> bal;
        if (bal >= total) {
            type = (payMethod == 1) ? "Debit" : "Credit";
            success = true;
        }
        else {
            cout << "Declined: Insufficient funds.\n";
        }
    }
    else if (payMethod == 3) {
        double cash;
        cout << "Cash given: $";
        cin >> cash;
        if (cash >= total) {
            type = "Cash";
            success = true;
            if (cash > total)
                cout << "Change: $" << (cash - total) << endl;
        }
        else {
            cout << "Not enough cash.\n";
        }
    }

    if (success) {
        printReceipt(*(*it), total, type, usedCard);
        inventory.erase(it);
    }
    else {
        cout << "Transaction failed.\n";
    }
}

// Print a formatted receipt
void InventoryManager::printReceipt(const Product& p, double total, const string& method, bool redCard) const {
    cout << "\n------------------------------\n";
    cout << "          TARGET RECEIPT      \n";
    cout << "------------------------------\n";
    cout << "Product:    " << p.getName() << endl;
    cout << "Department: " << p.getDepartment() << endl;
    cout << "DPCI:       " << p.getId() << endl;
    cout << "Payment:    " << method << endl;
    if (redCard) cout << "Discount:   5% RedCard Applied\n";
    cout << "Total Due:  $" << fixed << setprecision(2) << total << endl;
    cout << "------------------------------\n";
    cout << "  Thank you for shopping at\n";
    cout << "        Target. Please\n";
    cout << "      visit us again soon!\n";
    cout << "------------------------------\n";
}

// Display all items in inventory
void InventoryManager::displayInventory() const {
    if (inventory.empty()) {
        cout << "Inventory is empty.\n";
        return;
    }

    for (const auto& item : inventory) {
        item->display();
        cout << "------------------------------\n";
    }
}

