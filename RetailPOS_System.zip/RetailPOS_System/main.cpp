// main.cpp - Entry point for the POS system
// Provides a menu-driven interface to search, sell, add, and remove products

#include "Inventory.h"
#include <iostream>
#include <memory>
#include <iomanip>
#include <stdexcept>
using namespace std;

// changing the menu color to red to match Target's branding (extra credit)
void displayMenu() {
    const string HEADER = "\033[1;31m";  // Bold Red
    const string OPTION = "\033[1;37m";  
    const string PROMPT = "\033[1;33m";  
    const string RESET = "\033[0m";      

    cout << HEADER
        << "\n+-----------------------------------------+"
        << "\n|       Welcome to Target POS System      |"
        << "\n+-----------------------------------------+"
        << RESET << endl;

    cout << OPTION << " 1. Search Product Inventory" << RESET << endl;
    cout << OPTION << " 2. Hello, would you like to be rung up for an item? " << RESET << endl;
    cout << OPTION << " 3. Add New Stock (truck)  to Inventory" << RESET << endl;
    cout << OPTION << " 4. Remove a Product (damaged /discontinued/ purchase)" << RESET << endl;
    cout << OPTION << " 5. Exit POS System, Have a great day!" << RESET << endl;

    cout << PROMPT << "\nPlease enter your selection: " << RESET;
}

int main() {
    InventoryManager targetPOS;

    // Loads saved inventory list from file
    targetPOS.loadInventoryFromFile("/users/saraal-hachami/Desktop/cs!.2025/Sara_Alhachami/Sara_Alhachami/Sara_Alhachami/Inventory.txt");

    int menuChoice;
    try {
        do {
            displayMenu(); // show the menu
            cin >> menuChoice; // get user's option

            switch (menuChoice) {
            case 1: { // Searching inventory
                int searchType;
                cout << "\033[1;34mSearch Options:\033[0m\n";
                cout << " 1. Search by Department (Cosmetic, Snack, Drink, Tobacco, Lottery)\n";
                cout << " 2. Search by Product Name or ID ( Mascara or C01)\n";
                cout << " 3. Search by Price Range (Ex: 5.00 to 20.00)\n";
                cout << "\nEnter search option: ";
                cin >> searchType;

                if (searchType == 1) {
                    string dept;
                    cout << "Enter department name: ";
                    cin >> dept;
                    targetPOS.searchByCategory(dept);
                }
                else if (searchType == 2) {
                    string item;
                    cout << "Enter product name or ID: ";
                    cin >> item;
                    targetPOS.searchInventory(item);
                }
                else if (searchType == 3) {
                    double min, max;
                    cout << "Minimum price: $";
                    cin >> min;
                    cout << "Maximum price: $";
                    cin >> max;
                    targetPOS.searchByPriceRange(min, max);
                }
                else {
                    cout << "Invalid search option.\n";
                }
                break;
            }

            case 2:
                // Handles the entire sale transaction (payment, receipt, etc.)
                targetPOS.sellProduct();
                break;

            case 3: { // Adding new products to system

                cout << "\nChoose Department for New Product:\n";
                cout << " 1. Cosmetic\n 2. Snack\n 3. Drink\n 4. Tobacco\n 5. Lottery\n";
                cout << " 6. Household\n 7. Baby\n 8. Electronics\n 9. Clothing\n 10. Pet\n";

                int deptChoice;
                cin >> deptChoice;

                string productId, productName, expDate, department;
                double unitPrice;
                int stockQty;
                //different departments mean different products, etc
                switch (deptChoice) {
                case 1: department = "Cosmetic"; break;
                case 2: department = "Snack"; break;
                case 3: department = "Drink"; break;
                case 4: department = "Tobacco"; break;
                case 5: department = "Lottery"; break;
                case 6: department = "Household"; break;
                case 7: department = "Baby"; break;
                case 8: department = "Electronics"; break;
                case 9: department = "Clothing"; break;
                case 10: department = "Pet"; break;
                default:
                    cout << "Invalid department selection.\n";
                    return 0;
                }

                cout << "\nEnter Product ID (Ex: C01): ";
                cin >> productId;
                cout << "Product Name: ";
                cin >> productName;
                cout << "Expiration Date (YYYY-MM-DD): ";
                cin >> expDate;
                cout << "Unit Price: $";
                cin >> unitPrice;
                cout << "Quantity to Add: ";//when we add items from truck, it asks how much we recieved from the product
                cin >> stockQty;

                // Add product(s) depending on type
                for (int i = 0; i < stockQty; ++i) {
                    if (department == "Tobacco") {
                        double tax;
                        cout << "Enter Tobacco Tax: $";
                        cin >> tax;
                        targetPOS.addProduct(make_shared<Tobacco>(productId, department, productName, expDate, unitPrice, tax));
                    }
                    else if (department == "Lottery") {
                        double cityTax, countyTax;
                        cout << "Enter City Tax: $";
                        cin >> cityTax;
                        cout << "Enter County Tax: $";
                        cin >> countyTax;
                        targetPOS.addProduct(make_shared<LotteryTickets>(productId, department, productName, expDate, unitPrice, cityTax, countyTax));
                    }
                    else {
                        targetPOS.addProduct(make_shared<Product>(productId, department, productName, expDate, unitPrice));
                    }
                }
                break;
            }

            case 4:
                // Removes product from system
                targetPOS.removeProduct();
                break;

            case 5:
                // Exits program
                cout << "\nThank you for using the Target POS System. Goodbye!\n";
                break;

            default:
                cout << "Invalid menu option. Please try again.\n";
            }

        } while (menuChoice != 5);

        // Save inventory changes after session ends
        targetPOS.saveInventoryToFile("Inventory.txt");
    }
    catch (const exception& e) {
        cerr << "Error: " << e.what() << endl;
    }

    return 0;
}

