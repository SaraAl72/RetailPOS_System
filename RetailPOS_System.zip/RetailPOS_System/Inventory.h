// Inventory.h - Declares inventory management class
// Handles storing, adding, removing, and searching products

#pragma once
#include <vector>
#include <memory>
#include <string>
#include "Product.h"
#include "Tobacco.h"
#include "LotteryTickets.h"

// Inventory simulates a Target POS back-end system.
// It handles inventory tracking, product lookup, payment processing, and receipt printing.

class InventoryManager {
private:
    // stores all product items currently available in the store
    vector<shared_ptr<Product>> inventory;

public:
    // Loads inventory from file 
    void loadInventoryFromFile(const string& filename);

    // Saves current inventory to file (used at close or backup)
    void saveInventoryToFile(const string& filename) const;

    // Adds a product (Ex:snacks, cosmetics, tobacco) to inventory
    void addProduct(shared_ptr<Product> product);

    // Removes a product by DPCI or name
    void removeProduct();

    // Search by department Ex: Drink, Cosmetic, Tobacco)
    void searchByCategory(const string& category) const;

    // Search for products within a price range
    void searchByPriceRange(double minPrice, double maxPrice) const;

    // Search by product name or DPCI
    void searchInventory(const string& searchTerm) const;

    // Processes a product sale, includes payment and RedCard 5% discount if they qualify
    void sellProduct();

    // Prints full list of inventory (used for audits, reviews)
    void displayInventory() const;

    // Prints a Target-style receipt after a successful sale
    void printReceipt(const Product& product, double total, const string& paymentType, bool usedRedCard) const;
};
