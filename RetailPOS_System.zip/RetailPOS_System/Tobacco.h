// Tobacco.h - Derived class from Product
// Adds a special tax for tobacco products

#pragma once
#include "Product.h"
#include <string>
using namespace std;

//Consider it a branch from the Base class
class Tobacco : 

public Product {

private:
    //the tax applied onto tabacco products
    double tobaccoTax; 

public:
    //constructor that calls the Tabacco product and all its details
    Tobacco(const string& id, const string& category, const string& name, const string& expDate, double price, double specialTax);
    void display() const override;
    double registerPrice() const override; //calculates the price even with tax
    double getTobaccoTax() const;
    
};

