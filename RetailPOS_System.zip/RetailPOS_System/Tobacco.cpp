// Tobacco.cpp - Implements price computation including special tobacco tax

#include "Tobacco.h"
#include <iostream>
#include <iomanip>
using namespace std;

// Tobacco products are not sold at my Target location,
// but this implementation demonstrates how they would be processed in a POS system.

Tobacco::Tobacco(const string& id, const string& category, const string& name,
    const string& expDate, double price, double tobaccoTax)
    : Product(id, category, name, expDate, price), tobaccoTax(tobaccoTax) {}

void Tobacco::display() const {
    Product::display();
    cout << " | Tobacco Tax: $" << fixed << setprecision(2) << tobaccoTax;
}

double Tobacco::registerPrice() const {
    return price + tobaccoTax;
}

double Tobacco::getTobaccoTax() const {
    return tobaccoTax;
}

