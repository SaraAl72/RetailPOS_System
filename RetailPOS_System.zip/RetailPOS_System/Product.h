// Product.h - Base class for all products in the inventory
// Contains common attributes like ID, name, price, and virtual method for computing price

//Through out my code you will realize I've implemented many things I've learned through out the years of my retail experience at Target. It helped make the project seem easier in my eyes because I deal with a POS system almost everyday.
//I've included, DPCI as my product IDs, we don't use the word "Category" we use "department", I've added the Red Card system that we use at the register, as well as payment methods, etc.

#pragma once
#include <iostream>
#include <string>
using namespace std;

// Base class representing a product in Target's inventory system
class Product {
protected:
    // DPCI = Department-Class-Item code (used by Target for internal product ID)
    // Normally 9 digits, but shortened for this project
    string dpci;          // Product ID (Target uses DPCI codes)
    string department;      // Department or category (Ex: Snack, Cosmetic)
    string name;          // Product name (Ex: "Mascara")
    string expDate;       // Expiration date
    double price;         // Base price before taxes or discounts

public:
    // Constructor to initialize product details
    Product(const string& id, const string& category, const string& name, const string& expDate, double price);

    // Virtual destructor for safe cleanup in derived classes
    virtual ~Product();

    // Displays product information (polymorphisim)  
    virtual void display() const;

    // Returns the price
    //this is the equivelant to computePrice, just it made sense when I was applying it to target conext
    virtual double registerPrice() const;

    // Getters for accessing product details
    string getId() const;
    string getDepartment() const;
    string getName() const;
    string getExpDate() const;
};
