// LotteryTickets.cpp - Implements price calculation with dual taxes

#include "LotteryTickets.h"
#include <iostream>
#include <iomanip>
using namespace std;

// Constructor for a Lottery Ticket item.
// It initializes the base Product attributes and the two tax values.
LotteryTickets::LotteryTickets(
    const string& dpci,
    const string& department,
    const string& name,
    const string& expDate,
    double price,
    double cityTax,
    double countyTax
)
    : Product(dpci, department, name, expDate, price),
    cityTax(cityTax),
    countyTax(countyTax)
{}

// Prints the details of the lottery ticket item and that can include tax amounts.
void LotteryTickets::display() const {
    Product::display();
    cout << " | City Tax: $" << fixed << setprecision(2) << cityTax
        << " | County Tax: $" << fixed << setprecision(2) << countyTax;
}

// Calculates the final price including both city and county taxes.
double LotteryTickets::registerPrice() const {
    return price + cityTax + countyTax;
}

// Getter for city tax.
double LotteryTickets::getCityTax() const {
    return cityTax;
}

// Getter for county tax.
double LotteryTickets::getCountyTax() const {
    return countyTax;
}
