// LotteryTickets.h - Derived class from Product
// Includes city and county taxes for lottery ticket products

#pragma once
#include "Product.h"

// Lottery tickets are not sold at my Target location,
// but this is my implementation of how they might be managed in our POS system.

class LotteryTickets : public Product {
private:
    double cityTax;     
    double countyTax;   

public:
    // Constructor includes all required ticket details and taxes
    LotteryTickets(const string& id, const string& category, const string& name,
        const string& expDate, double price, double cityTax, double countyTax);

    // Displays product and tax details in a Target POS style
    void display() const override;

    // Returns full price including all applicable taxes
    double registerPrice() const override;

    // Getters for tax information
    double getCityTax() const;
    double getCountyTax() const;
};
