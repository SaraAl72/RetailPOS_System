// Product.cpp - Implements the base Product class functions

#include "Product.h"
#include <iomanip> // for formatting prices

// Constructor: initializes a product in the Target inventory system
Product::Product(const string& dpci, const string& department, const string& name, const string& expDate, double price)
    : dpci(dpci), department(department), name(name), expDate(expDate), price(price) {}

// Destructor
Product::~Product() {}

// Display product details in a Target-like format
void Product::display() const {
    cout << "DPCI: " << dpci
        << "\nDepartment: " << department
        << "\nProduct Name: " << name
        << "\nExpiration Date: " << expDate
        << "\nPrice: $" << fixed << setprecision(2) << price << endl;
}

// Returns the base price; could include taxes or Target Circle offers in derived classes
double Product::registerPrice() const {
    return price;
}

// Getters for product details
string Product::getId() const {
    return dpci;
}

string Product::getDepartment() const {
    return department;
}

string Product::getName() const {
    return name;
}

string Product::getExpDate() const {
    return expDate;
}


